# Code of Conduct for bot-github-chatops

Please see the [Community Code of Conduct on the Foundation wiki](https://symphonyoss.atlassian.net/wiki/spaces/FM/pages/126648367/Community+Code+of+Conduct").
