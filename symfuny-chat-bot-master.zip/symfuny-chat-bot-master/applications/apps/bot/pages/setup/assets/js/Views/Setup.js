Package('Bot.Views', {
	Setup : new Class({
		Extends : Sapphire.View,

		initialize : function()
		{
			this.parent();
		},

		draw : function()
		{
		}
	})
});
