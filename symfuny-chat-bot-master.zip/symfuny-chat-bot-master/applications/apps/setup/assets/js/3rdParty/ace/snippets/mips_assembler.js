define("ace/snippets/mips_assembler",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "mips_assembler";

});
