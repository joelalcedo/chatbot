Package('Setup.Views', {
	Start : new Class({
		Extends : Sapphire.View,

		initialize : function()
		{
			this.parent();
		},

		draw : function()
		{
		}
	})
});
