module.exports = {
	useCompression: false,
	builderCache: false,
	minify : false,
};
