module.exports = {
	useCompression: true,
	builderCache: true,
	minify : true,
};
